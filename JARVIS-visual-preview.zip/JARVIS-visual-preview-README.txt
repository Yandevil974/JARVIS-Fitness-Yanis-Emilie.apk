JARVIS Fitness Evolution · style photo animé validé

Modèles cohérents :
- jarvis-man-avatar.png : homme chauve, peau marron, musculature renforcée, visage constant
- jarvis-woman-avatar.png : femme, poitrine légèrement plus généreuse, visage constant

Démonstration :
- jarvis-incline-lateral-raise.gif : 480 x 262, 2 positions, 500 ms par image
- jarvis-incline-lateral-raise.mp4 : même enchaînement en vidéo
- visual-preview.html : aperçu web

Règle de rendu : décor lumineux de salle de sport, machines adaptées à chaque exercice,
seuls les muscles travaillés en vert. La génération complète des visuels exercice par
exercice doit respecter le mouvement, l'outil et l'angle prescrits ; elle ne doit pas
être remplacée par une image générique.
