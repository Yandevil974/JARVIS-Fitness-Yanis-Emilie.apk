JARVIS Fitness · aperçu visuels V1

Contenu :
- jarvis-man-avatar.png : exemple homme, visage créé
- jarvis-woman-avatar.png : exemple femme, visage créé
- jarvis-curl-example.gif : exemple d'exercice en GIF
- jarvis-curl-example.mp4 : le même exercice en vidéo
- visual-preview.html : aperçu ouvrable dans le navigateur via le serveur de l'application

Style : rendu anatomique 3D monochrome, fond studio sombre, muscles actifs en vert.
La préférence GIF/vidéo doit être confirmée avant la génération complète de tous les mouvements.
